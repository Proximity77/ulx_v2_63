### Steps to reproduce
1.
2.
3.

### Expected behavior
Tell us what should happen

### Actual behavior
Tell us what happens instead

### Error(s) in server console, if any

### Error(s) in player's console, if any

### Version
Run "ulx version" in console and paste the result
